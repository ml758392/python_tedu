# Ansible-zabbix-agent-roles
使用ansible来实现zabbix客户端的自动安装，安装的zabbix agent版本是zabbix-2.4.5-1
